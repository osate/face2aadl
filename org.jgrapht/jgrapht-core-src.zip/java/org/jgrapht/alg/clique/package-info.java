/**
 * Clique related algorithms.
 */
package org.jgrapht.alg.clique;
