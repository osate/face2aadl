/**
 * Algorithm for computing partitions.
 */
package org.jgrapht.alg.partition;
